<template>
  <section>
    <div>
      <img src="http://localhost:8666/resources/images/weixin.png" alt="">
    </div>
  </section>
</template>
