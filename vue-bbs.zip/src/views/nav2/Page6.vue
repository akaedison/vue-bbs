<template>
  <section>
    <!--工具条-->
    <!--   <el-col :span="24" class="toolbar" style="padding-bottom: 0px;">
         <el-form :inline="true" :model="filters">
           <el-form-item>
             <el-input v-model="filters.name" placeholder="关键词"></el-input>
           </el-form-item>
           <el-form-item>
             <el-button type="primary" v-on:click="getUsers">查询</el-button>
           </el-form-item>
           <el-form-item>
             <el-button type="primary" @click="handleAdd">新增</el-button>
           </el-form-item>
         </el-form>
       </el-col>-->

    <!--列表-->
    <el-table :data="hotArticles" highlight-current-row v-loading="listLoading" @selection-change="selsChange"
              style="width: 100%;">
      <el-table-column v-if="false" type="selection" width="55">
      </el-table-column>
      <el-table-column v-if="false" type="index" width="60">
      </el-table-column>
      <el-table-column v-if="false" prop="id" label="帖子id" width="120" sortable>
      </el-table-column>
      <el-table-column prop="pic" label="配图" width="120"  sortable>
        <template slot-scope="scope">
          <img :src="'http://localhost:8666/resources/images/'+scope.row.pic" style="width: 100px;height:100px;">
        </template>
      </el-table-column>
      <el-table-column prop="plate" label="板块" width="100" :formatter="formatPlate" sortable>
      </el-table-column>
      <el-table-column prop="writer" label="作者" width="100" sortable>
      </el-table-column>
      <el-table-column prop="title" label="标题" width="120" sortable>
      </el-table-column>
      <el-table-column prop="text" label="内容" width="800"  :show-overflow-tooltip='true' sortable>
      </el-table-column>
      <el-table-column label="操作" width="150">
        <template scope="scope">
          <el-button size="small" @click="handleEdit(scope.$index, scope.row)">查看</el-button>
        </template>
      </el-table-column>
    </el-table>

    <!--工具条-->
    <el-col :span="24" class="toolbar">
      <el-pagination layout="prev, pager, next" @current-change="handleCurrentChange" :page-size="5" :total="total"
                     style="float:right;">
      </el-pagination>
    </el-col>

    <!--帖子界面-->
    <el-dialog title="查看帖子" :visible.sync="editFormVisible" :close-on-click-modal="false">

      <el-form :model="commentForm" label-width="80px" :rules="commentFormRules" ref="commentForm">
        <h1 align="center">{{commentForm.title}}</h1>
        <img align="center" :src="'http://localhost:8666/resources/images/'+commentForm.pic" style="width: 300px;height:300px;margin-left: 270px">
        <h4>{{commentForm.text}}</h4>
      </el-form>

      <el-table :data="comments" highlight-current-row  @selection-change="selsChange"
                style="width: 100%;">
        <el-table-column v-if="false" type="selection" width="55">
        </el-table-column>
        <el-table-column v-if="false" type="index" width="60">
        </el-table-column>
        <el-table-column v-if="false" prop="cid" label="评论id" width="120" sortable>
        </el-table-column>
        <el-table-column prop="uid" label="评论人" width="150">
        </el-table-column>
        <el-table-column prop="ccomment" label="评论" width="700">
        </el-table-column>
      </el-table>

      <div slot="footer" class="dialog-footer">
        <el-form :model="commentUpForm" label-width="80px" :rules="commentFormRules" ref="commentUpForm">
          <el-form-item label="评论" prop="ccomment">
            <el-input v-model="commentUpForm.ccomment" auto-complete="off"></el-input>
          </el-form-item>
          <el-form-item v-show="false" label="评论人" prop="uid">
            <el-input  v-model="commentUpForm.uid" auto-complete="off"></el-input>
          </el-form-item>

        </el-form>
        <el-button type="primary" @click.native="commentSubmit" :loading="editLoading">评论</el-button>
      </div>
    </el-dialog>

    <!--新增界面-->
    <el-dialog title="发帖" :visible.sync="addFormVisible" :close-on-click-modal="false">
      <el-form :model="addForm" label-width="80px" :rules="addFormRules" ref="addForm">
        <el-form-item v-show="false" label="id" prop="id">
          <el-input v-model="addForm.id" auto-complete="off"></el-input>
        </el-form-item>
        <el-form-item  label="作者" prop="writer">
          <el-input v-model="addForm.writer" auto-complete="off"></el-input>
        </el-form-item>
        <el-form-item label="板块">
          <el-radio-group v-model="addForm.plate">
            <el-radio class="radio" :label="1">可感知性</el-radio>
            <el-radio class="radio" :label="2">可操作性</el-radio>
            <el-radio class="radio" :label="3">可理解</el-radio>
            <el-radio class="radio" :label="4">稳定性</el-radio>
          </el-radio-group>
        </el-form-item>
        <el-form-item  label="标题" prop="title">
          <el-input v-model="addForm.title" auto-complete="off"></el-input>
        </el-form-item>
        <el-form-item  label="正文" prop="text">
          <el-input v-model="addForm.text" auto-complete="off"></el-input>
        </el-form-item>

      </el-form>
      <el-upload
        class="avatar-uploader"
        action="http://localhost:18886/article/fileUp"
        :show-file-list="false"
        :on-success="handleAvatarSuccess"
        :before-upload="beforeAvatarUpload">
        <img v-if="imageUrl" :src="imageUrl" class="avatar">
        <i v-else class="el-icon-plus avatar-uploader-icon"></i>
      </el-upload>
      <div slot="footer" class="dialog-footer">
        <el-button @click.native="addFormVisible = false">取消</el-button>
        <el-button type="primary" @click.native="addSubmit" :loading="addLoading">提交</el-button>
      </div>
    </el-dialog>
  </section>
</template>

<script>
  import util from '../../common/js/util'
  import defaultImg from '../../../public/123.jpg'
  import {
    removeUser,
    batchRemoveUser,
    insertComment,
    addUser,
    getHotArticle,
    getComment,
    addArticle, getOneArticle, getTwoArticle, getThreeArticle
  } from '../../api/api'

  export default {
    data () {
      return {
        filters: {
          name: ''
        },
        imageUrl: '',
        CurUser: '',
        sysUserName: '',
        defaultImg: defaultImg,
        hotArticles: [],
        comments: [],
        total: 0,
        page: 1,
        listLoading: false,
        sels: [], // 列表选中列

        editFormVisible: false, // 编辑界面是否显示
        editLoading: false,
        commentFormRules: {

        },
        // 编辑界面数据
        commentForm: {
          id: 0,
          plate: '',
          writer: '',
          title: '',
          text: '',
          pic: '',
          comment: '',
          commentP: ''
        },
        commentUpForm: {
          aid: '',
          ccomment: '',
          cid: '',
          uid: ''
        },

        addFormVisible: false, // 新增界面是否显示
        addLoading: false,
        addFormRules: {
          name: [
            { required: true, message: '请输入姓名', trigger: 'blur' }
          ]
        },
        // 新增界面数据
        addForm: {
          name: '',
          sex: -1,
          age: 0,
          birth: '',
          addr: ''
        }

      }
    },
    methods: {



      handleAvatarSuccess(res, file) {
        this.imageUrl = URL.createObjectURL(file.raw);
      },
      beforeAvatarUpload(file) {
        const isJPG = file.type === 'image/jpeg';
        const isLt2M = file.size / 1024 / 1024 < 2;

        if (!isJPG) {
          this.$message.error('上传图片只能是 JPG 格式!');
        }
        if (!isLt2M) {
          this.$message.error('上传图片大小不能超过 2MB!');
        }
        return isJPG && isLt2M;
      },

      getUsers () {

      },

      // 板块显示转换
      formatPlate: function (row, column) {
        return row.plate == 1 ? '可感知性' : row.plate == 2 ? '可操作性' : row.plate == 3 ? '可理解' : row.plate == 4 ? '稳定性': "其它"
      },
      handleCurrentChange (val) {
        this.page = val
        this.getHotArticles()
      },
      // 获取热门帖子列表
      getHotArticles () {
        let para = {
          page: this.page
        }
        this.listLoading = true
        getThreeArticle(para).then((res) => {
          this.total = res.data.total
          this.hotArticles = res.data.list
          this.listLoading = false
        })
      },
      // 获取评论
      getComments :function (row) {
        let para = {
          aID: row.id
        }
        this.listLoading = true
        getComment(para).then((res) => {
          this.total = res.data.total
          this.comments = res.data
        })
      },
      // 查看文章界面
      handleEdit: function (index, row) {
        let para = {aID: row.id}
        this.editFormVisible = true
        this.commentForm = Object.assign({}, row)
        getComment(para).then((res) => {
          this.listLoading = false
          this.comments = res.data
          this.getUsers()
        })
      },


      // 显示新增界面
      handleAdd: function () {
        this.addFormVisible = true
        this.addForm = {
          id: 0,
          plate: '',
          writer: '',
          title: '',
          text: '',
          pic: '',
          comment: '',
          commentP: ''
        }
      },
      // 评论
      commentSubmit: function () {
        this.$refs.commentUpForm.validate((valid) => {
          if (valid) {
            this.$confirm('确认提交吗？', '提示', {}).then(() => {
              this.editLoading = true
              this.aid = this.commentForm.id
              this.uid = this.CurUser
              this.ccomment = this.commentUpForm.ccomment
              let para = {
                'aid' : this.commentForm.id,
                'ccomment' : this.commentUpForm.ccomment,
                'cid' : 0,
                'uid' : this.CurUser
              }
              insertComment(para).then((res) => {
                this.editLoading = false
                this.$message({
                  message: '提交成功',
                  type: 'success'
                })
                this.$refs['commentForm'].resetFields()
                this.editFormVisible = false
              })
            })
          }
        })
      },
      // 新增
      addSubmit: function(){
        this.$refs.commentUpForm.validate((valid) => {
          if (valid) {
            this.$confirm('确认提交吗？', '提示', {}).then(() => {
              this.editLoading = true

              let para = Object.assign({}, this.addForm)
              addArticle(para).then((res) => {
                this.editLoading = false
                this.$message({
                  message: '提交成功',
                  type: 'success'
                })
                this.$refs['addForm'].resetFields()
                this.editFormVisible = false
                this.getUsers()
              })
            })
          }
        })
      },

      selsChange: function (sels) {
        this.sels = sels
      },
      // 批量删除
      batchRemove: function () {
        var ids = this.sels.map(item => item.id).toString()
        this.$confirm('确认删除选中记录吗？', '提示', {
          type: 'warning'
        }).then(() => {
          this.listLoading = true
          let para = { ids: ids }
          batchRemoveUser(para).then((res) => {
            this.listLoading = false
            this.$message({
              message: '删除成功',
              type: 'success'
            })
            this.getUsers()
          })
        }).catch(() => {

        })
      }
    },
    mounted () {

      var user = sessionStorage.getItem('user')
      if (user) {
        user = JSON.parse(user)
        this.CurUser = user
      }
      this.getHotArticles()
    }
  }

</script>

<style scoped>
  .avatar-uploader .el-upload {
    border: 1px dashed #d9d9d9;
    border-radius: 6px;
    cursor: pointer;
    position: relative;
    overflow: hidden;
  }
  .avatar-uploader .el-upload:hover {
    border-color: #409EFF;
  }
  .avatar-uploader-icon {
    font-size: 28px;
    color: #8c939d;
    width: 178px;
    height: 178px;
    line-height: 178px;
    text-align: center;
  }
  .avatar {
    width: 178px;
    height: 178px;
    display: block;
  }
</style>
