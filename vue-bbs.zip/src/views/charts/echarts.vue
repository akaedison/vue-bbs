<template>
  <section>
    <div>
      <img src="http://localhost:8666/resources/images/intnet.png" alt="">
      <img src="http://localhost:8666/resources/images/canji.png" alt="">
    </div>
  </section>
</template>
