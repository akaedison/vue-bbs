import Vue from 'vue'
import Router from 'vue-router'
Vue.use(Router)
export default new Router({
  mode: 'history',
  base: process.env.BASE_URL,
  routes: [
    {
      path: '/login',
      component: () => import('./views/Login.vue'),
      name: '',
      hidden: true
    },
    {
      path: '/404',
      component: () => import('./views/404.vue'),
      name: '',
      hidden: true
    },
    {
      path: '/',
      component: () => import('./views/Home.vue'),
      name: '主页',
      iconCls: 'el-icon-message  ', // 图标样式class
      children: [
        { path: '/main', component: () => import('./views/Main.vue'), name: '主页', hidden: true },
        { path: '/table', component: () => import('./views/nav1/Table.vue'), name: '推荐帖子' },
        { path: '/form', component: () => import('./views/nav1/Form.vue'), name: '全部帖子' },
      ]
    },
    {
      path: '/',
      component: () => import('./views/Home.vue'),
      name: '板块浏览',
      iconCls: 'fa fa-id-card-o',
      children: [
        { path: '/page4', component: () => import('./views/nav2/Page4.vue'), name: '可感知性' },
        { path: '/page5', component: () => import('./views/nav2/Page5.vue'), name: '可操作性' },
        { path: '/page6', component: () => import('./views/nav2/Page6.vue'), name: '可理解' },
        { path: '/page7', component: () => import('./views/nav2/Page7.vue'), name: '稳定性' }
      ]
    },
    {
      path: '/',
      component: () => import('./views/Home.vue'),
      name: '',
      iconCls: 'fa fa-address-card',
      leaf: true,
      children: [
        { path: '/page8', component: () => import('./views/nav3/Page8'), name: '联系我们' }
      ]
    },
    {
      path: '/',
      component: () => import('./views/Home.vue'),
      name: '图表',
      iconCls: 'fa fa-bar-chart',
      children: [
        { path: '/echarts', component: () => import('./views/charts/echarts.vue'), name: '上网人数' }
      ]
    },
    {
      path: '*',
      hidden: true,
      redirect: { path: '/404' }
    }
  ]
})
