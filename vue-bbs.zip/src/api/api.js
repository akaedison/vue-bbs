import axios from 'axios'

let base = 'http://localhost:18886'

export const requestLogin = params => { return axios.post(`${base}/user/login`, params).then(res => res.data) }

export const requestRegister = params => { return axios.post(`${base}/user/register`, params).then(res => res.data) }

export const getHotArticle = params => { return axios.get(`${base}/article/selectHot`, { params: params }) }

export const getComment = params => { return axios.get(`${base}/article/selectComment`, { params: params }) }

export const insertComment = params => { return axios.post(`${base}/article/insertComment`, params).then(res => res.data) }

export const addArticle = params => { return axios.post(`${base}/article/insertArticle`, params).then(res => res.data)}

export const getAllArticles = params => { return axios.get(`${base}/article/selectAll`, { params: params }) }

export const getArticleByKeywords = params => { return axios.get(`${base}/article/selectKeywords`, { params: params }) }

export const getOneArticle = params => { return axios.get(`${base}/article/selectOne`, { params: params }) }

export const getTwoArticle = params => { return axios.get(`${base}/article/selectTwo`, { params: params }) }

export const getThreeArticle = params => { return axios.get(`${base}/article/selectThree`, { params: params }) }

export const getFourArticle = params => { return axios.get(`${base}/article/selectFour`, { params: params }) }
